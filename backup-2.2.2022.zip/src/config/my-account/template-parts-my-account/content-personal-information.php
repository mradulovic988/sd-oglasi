<?php
/**
 * Template for Personal information page on My account
 */
echo 'Osnovni podaci naloga';