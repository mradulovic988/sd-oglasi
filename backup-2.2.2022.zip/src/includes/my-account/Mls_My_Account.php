<?php
/**
 * Class Mls_My_Account
 *
 * All methods for my account page
 *
 * @class Mls_My_Account
 * @package Mls_My_Account
 * @version 1.0.0
 * @since 1.0.0
 * @author M Lab Studio
 */

if ( ! class_exists( 'Mls_My_Account' ) ) {
	class Mls_My_Account {
		public function __construct() {

		}
	}

	new Mls_My_Account();
}