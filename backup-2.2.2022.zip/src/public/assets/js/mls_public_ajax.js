jQuery(document).ready(function ($) {
    if ($("body").hasClass("logged-in")) {

    }
});