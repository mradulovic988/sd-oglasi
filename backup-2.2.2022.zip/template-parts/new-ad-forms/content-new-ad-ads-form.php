<h2>Oglasi</h2>
<div class="mls-home-form-wrapper">
	<?php get_template_part( 'template-parts/new-ad-forms/ads-content/content', 'ads-content' ); ?>
</div>
